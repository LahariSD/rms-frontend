import React from "react";
import MarksDashboard from "../../components/MarksDashboard";

const AdminDashboard = () => {
  return (
    <>
      <MarksDashboard />
    </>
  );
};

export default AdminDashboard;
